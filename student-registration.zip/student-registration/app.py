
import os
import re

import boto3
from flask import Flask, request, render_template_string
from botocore.exceptions import ClientError

app = Flask(__name__)

REGION = "us-east-1"
TABLE_NAME = "24BCA7892"
TOPIC_ARN = (
    "arn:aws:sns:us-east-1:030979100024:"
    "StudentRegistration_24BCA7892"
)

dynamodb = boto3.resource("dynamodb", region_name=REGION)
table = dynamodb.Table(TABLE_NAME)
sns = boto3.client("sns", region_name=REGION)

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Student Registration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef2f7;
            padding: 25px 12px;
        }
        .container {
            max-width: 520px;
            margin: auto;
            padding: 25px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 12px #ccd2dc;
        }
        h1 { text-align: center; color: #173b70; }
        label { display: block; margin-top: 14px; }
        input, select {
            box-sizing: border-box;
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #bbb;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 12px;
            margin-top: 22px;
            color: white;
            background: #1769aa;
            border: 0;
            border-radius: 5px;
            cursor: pointer;
        }
        .message { font-weight: bold; text-align: center; }
    </style>
</head>
<body>
<div class="container">
    <h1>Student Registration</h1>
    {% if message %}
        <p class="message">{{ message }}</p>
    {% endif %}
    <form method="POST">
        <label>University Roll Number</label>
        <input name="roll" maxlength="50" required>

        <label>Student Name</label>
        <input name="name" maxlength="100" required>

        <label>Course Name</label>
        <input name="course" maxlength="100" required>

        <label>Address</label>
        <input name="address" maxlength="300" required>

        <label>Email</label>
        <input type="email" name="email" maxlength="254" required>

        <label>Year of Study</label>
        <select name="year" required>
            <option value="">Select year</option>
            <option value="1">1st Year</option>
            <option value="2">2nd Year</option>
            <option value="3">3rd Year</option>
            <option value="4">4th Year</option>
        </select>

        <button type="submit">Register Student</button>
    </form>
</div>
</body>
</html>
"""


@app.route("/", methods=["GET", "POST"])
def register():
    message = ""

    if request.method == "POST":
        roll = request.form.get("roll", "").strip()
        name = request.form.get("name", "").strip()
        course = request.form.get("course", "").strip()
        address = request.form.get("address", "").strip()
        email = request.form.get("email", "").strip()
        year = request.form.get("year", "").strip()

        if not all([roll, name, course, address, email, year]):
            return render_template_string(
                HTML, message="Complete all fields."
            ), 400

        if not re.fullmatch(r"[1-4]", year):
            return render_template_string(
                HTML, message="Invalid year of study."
            ), 400

        try:
            table.put_item(
                Item={
                    "RollNumber": roll,
                    "StudentName": name,
                    "CourseName": course,
                    "Address": address,
                    "Email": email,
                    "YearOfStudy": int(year),
                    "RegistrationStatus": "SUCCESS"
                },
                ConditionExpression="attribute_not_exists(RollNumber)"
            )
        except ClientError as exc:
            code = exc.response["Error"]["Code"]

            if code == "ConditionalCheckFailedException":
                return render_template_string(
                    HTML, message="Roll number already registered."
                ), 409

            app.logger.exception("DynamoDB insertion failed")
            return "Database insertion failed. Check CloudShell logs.", 500

        try:
            sns.publish(
                TopicArn=TOPIC_ARN,
                Subject="Student Registration Successful",
                Message=(
                    "Student Registration Notification\n\n"
                    f"University Roll Number: {roll}\n"
                    f"Student Name: {name}\n"
                    f"Course Name: {course}\n"
                    "Registration Status: SUCCESS\n"
                )
            )
        except ClientError:
            app.logger.exception("SNS publication failed")
            return (
                "Details saved in DynamoDB, but SNS publication failed. "
                "Check permissions before retrying the notification.",
                500
            )

        message = (
            f"Registration successful for {roll}. "
            "SNS notification published."
        )

    return render_template_string(HTML, message=message)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)

